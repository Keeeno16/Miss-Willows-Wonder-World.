WILLOW'S WONDERS - MOBILE PLAYTEST 0.4.3

This is the actual exported Godot browser game, not the old single-page prototype.
Host every file in this directory together on an HTTPS static website. Keep the
names unchanged. The entry page is index.html. No build command is needed for
these already exported files. Supply application/wasm MIME type for index.wasm.
Use HTTP compression (gzip/Brotli) for download efficiency.

DO NOT OPEN index.html DIRECTLY IN THE IPHONE FILES APP.
The game must be served over HTTPS. A personal HTTPS test site is not live yet.
No threads, shared-array-buffer or cross-origin isolation headers are required.
No PWA cache is installed in this first build, so updates do not stick on old versions.
A published link will be accessible to anyone who has it; no authentication is included.

Tap to start in landscape. Move: left thumbstick. RUN: right-thumb toggle.
TALK / PLAY: right-side action. Menu: help / motion / character viewer / return.
Desktop keys also remain available. FPS counter is a diagnostic, not a benchmark.

Progress is session-only and resets on reload. No recorded teacher narration yet.
Optional existing reward chime is included. No new paid service or voice clone.
The two test suites ran in native Godot 4.6.3; actual Safari performance is unverified.
See the separate validation report for all remaining device/browser tests.
